// ============================================================
// api/webhook-mercadopago.js
// Endpoint: POST /api/webhook-mercadopago
//   (URL registrada no painel do Mercado Pago > Webhooks > Pagamentos)
//
// Recebe a notificação, RE-CONSULTA o pagamento na API oficial do
// Mercado Pago (nunca confia no corpo da mensagem) e, quando o
// status é "approved":
//   - marca o pedido como pago no Firebase
//   - libera/ativa o acesso do cliente automaticamente
// Sem confirmação manual.
// ============================================================

import crypto from 'crypto';
import { mpGetPayment, ativarAcesso } from './_pix-lib.js';

export default async function handler(req, res) {
  const body = typeof req.body === 'string' ? JSON.parse(req.body || '{}') : (req.body || {});

  const tipo = String(req.query.type || req.query.topic || body.type || body.topic || '');

  // id do pagamento: formato novo (data.id) e antigo (?topic=payment&id=...)
  let pid = String(req.query['data.id'] || (body.data && body.data.id) || '');
  if (!pid && tipo === 'payment') {
    pid = String(req.query.id || body.id || '');
  }

  // valida a assinatura do MP (só ativa se MERCADOPAGO_WEBHOOK_SECRET estiver configurada)
  if (!validarAssinatura(req, pid)) {
    return res.status(401).json({ ok: false, erro: 'Assinatura inválida' });
  }

  try {
    if (pid && (tipo === '' || tipo === 'payment')) {
      const p = await mpGetPayment(pid);   // fonte da verdade é a API do MP
      if (p && p.status === 'approved') {
        await ativarAcesso(p);             // marca pago no banco + ativa o cliente
      }
    }
    // SEMPRE responder 200 rápido, senão o Mercado Pago fica reenviando
    return res.status(200).json({ ok: true, recebido: true });
  } catch (e) {
    console.error('webhook-mercadopago:', e.message);
    // responde 200 mesmo com erro: a consulta de 5s no status-pix faz a auto-cura
    return res.status(200).json({ ok: false, recebido: true, erro: e.message });
  }
}

// Validação opcional da assinatura (header x-signature do Mercado Pago)
function validarAssinatura(req, dataId) {
  const secret = process.env.MERCADOPAGO_WEBHOOK_SECRET;
  if (!secret) return true; // sem secret: pula (a proteção real é re-consultar a API do MP)

  const header = String(req.headers['x-signature'] || '');
  const partes = {};
  header.split(/[,;]/).forEach(function (p) {
    const kv = p.trim().split('=');
    if (kv.length === 2) partes[kv[0]] = kv[1];
  });
  if (!partes.ts || !partes.v1) return false;

  const requestId = String(req.headers['x-request-id'] || '');
  const manifest = 'id:' + dataId + ';request-id:' + requestId + ';ts:' + partes.ts + ';';
  const hmac = crypto.createHmac('sha256', secret).update(manifest).digest('hex');
  return hmac === partes.v1;
}
