# Pix dinâmico Mercado Pago — NEGRET'S (pool-piscina-pro)

Ativação automática por Pix via API: o cliente paga, o Mercado Pago avisa, o backend marca como pago no Firebase e libera o acesso sozinho. Sem QR estático, sem `gerarPix`, sem `crc16`, sem confirmação manual.

## 1. Arquivos e onde colocar no repo

| Arquivo | Colocar em | O que faz |
|---|---|---|
| `api/_pix-lib.js` | pasta `api/` | Funções compartilhadas (Firebase + Mercado Pago). Não cria endpoint. |
| `api/criar-pix.js` | pasta `api/` | `POST /api/criar-pix` — cria o Pix e devolve `id`, `qr_code`, `qr_code_base64`. |
| `api/status-pix.js` | pasta `api/` | `GET /api/status-pix?id=...` — status do pagamento; o frontend consulta a cada 5s. |
| `api/webhook-mercadopago.js` | pasta `api/` | `POST /api/webhook-mercadopago` — com pagamento aprovado, marca pago e ativa o cliente. |
| `pix-teste.html` | raiz do repo | Página de teste dos endpoints; o bloco `<script>` dela é o que vai para o `index.html`. |

## 2. Variáveis de ambiente (Vercel → Settings → Environment Variables)

| Nome | Valor | Onde pegar |
|---|---|---|
| `MERCADOPAGO_ACCESS_TOKEN` | Access Token de PRODUÇÃO | Painel MP → Suas integrações → sua aplicação → Credenciais de produção |
| `FIREBASE_DATABASE_URL` | `https://SEU-PROJETO-default-rtdb.firebaseio.com` | Console Firebase → Realtime Database → URL no topo |
| `FIREBASE_DB_SECRET` | Secret do banco de dados | Console Firebase → Configurações do projeto → Contas de serviço → Database secrets |
| `MERCADOPAGO_WEBHOOK_SECRET` (opcional) | Chave secreta do webhook | Painel MP → Webhooks (só se quiser validar a assinatura) |

Importante: o Access Token fica SÓ no backend (variável de ambiente). Nunca colar no `index.html`. Depois de salvar as variáveis, clique em **Redeploy** na Vercel para valer.

## 3. Registrar o webhook no Mercado Pago

Painel MP → Suas integrações → sua aplicação → **Webhooks** → URL de produção:

```
https://SEU-APP.vercel.app/api/webhook-mercadopago
```

Evento: **Pagamentos** (payments). Salvar.

## 4. Colar no index.html (substituir o QR estático)

1. Apague do `index.html`: a função `gerarPix`, a função `crc16`, o QR estático com sua chave Pix e a biblioteca de QR, se houver.
2. Copie o bloco `<script>` inteiro do `pix-teste.html` (comentado como "BLOCO PIX DINÂMICO") para dentro do `index.html`.
3. Onde hoje abre o QR estático depois do trial, chame:

```js
criarPixCom(19.90, clienteId);   // valor do plano e cliente_id do usuário logado
```

O que acontece depois: aparece o QR (imagem pronta do Mercado Pago) + botão copia e cola; a cada 5 segundos consulta `/api/status-pix`; quando paga, mostra **"Pagamento confirmado"** — e o acesso já foi liberado no Firebase pelo backend.

## 5. O que é gravado no Firebase

```
pix_pagamentos/{id} : cliente_id, valor, status (pendente → pago), criado_em, pago_em, valor_pago
clientes/{cliente_id}/ativo : true
clientes/{cliente_id}/ativado_em : (data)
clientes/{cliente_id}/pagamento_id : {id}
comandos/{cliente_id} : { tipo: "ativar", pagamento_id, ts }
```

Se o seu app libera o acesso lendo outro campo (ex.: `plano_ativo`, `licenca_ate`), ajuste em `api/_pix-lib.js`, função `ativarAcesso`, onde está marcado `AJUSTE AQUI`.

## 6. Como testar

1. Faça o deploy na Vercel e abra `https://SEU-APP.vercel.app/pix-teste.html`.
2. Coloque valor (ex.: `1.00`) e o seu `cliente_id` → **GERAR PIX**.
3. Pague o QR no app do banco.
4. Em segundos deve aparecer "Pagamento confirmado" (pelo webhook ou pela consulta de 5s — as duas vias ativam).
5. Confirme no Firebase: `clientes/{seu_id}/ativo = true`.

## 7. Se algo não funcionar

- **QR não aparece** → o token é de produção? As variáveis foram salvas e o projeto foi reimplantado (Redeploy)?
- **Fica só no "Aguardando pagamento"** → confira a URL do webhook no painel MP. Não é fatal: o `status-pix` pergunta direto ao Mercado Pago a cada 5s e ativa igual.
- **Pagou mas o app não liberou** → os nomes dos campos no Firebase estão diferentes dos que o app lê? Ajuste o bloco `AJUSTE AQUI` em `_pix-lib.js`.
- **Erro 401 assinatura** → se configurou `MERCADOPAGO_WEBHOOK_SECRET`, copie a chave do mesmo lugar da URL do webhook.

## 8. Opcional: URLs sem o `/api`

Se quiser `/criar-pix` em vez de `/api/criar-pix`, adicione (ou junte) no `vercel.json` da raiz:

```json
{
  "rewrites": [
    { "source": "/criar-pix", "destination": "/api/criar-pix" },
    { "source": "/status-pix", "destination": "/api/status-pix" },
    { "source": "/webhook-mercadopago", "destination": "/api/webhook-mercadopago" }
  ]
}
```

Sem isso, os endereços `/api/...` já funcionam de cara.

## 9. Segurança embutida

- Access Token só no backend (variável de ambiente) — nunca aparece no frontend.
- O webhook nunca confia no corpo da notificação: sempre re-consulta o pagamento na API oficial do Mercado Pago antes de ativar.
- O `external_reference` do pagamento é conferido com o pedido registrado no Firebase antes de liberar o cliente.
- O botão `ativar-manual` continua funcionando como backup para casos raros (ex.: pagamento por fora).
